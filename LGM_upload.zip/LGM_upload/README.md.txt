# LGM Grey Model for Strength Degradation Prediction Under Freeze-Thaw Cycles

This MATLAB project implements the LGM (Grey Model) for predicting the strength degradation of materials under freeze-thaw cycles. The model is based on differential equations and is fit to experimental data to predict material strength after a certain number of freeze-thaw cycles.

## Description

This script uses the Grey Model (LGM) to model the degradation of material strength under freeze-thaw cycles. It fits the model to observed data and predicts the material strength for future freeze-thaw cycles.

The script uses MATLAB's `lsqcurvefit` function to fit the model parameters (`lambda1` and `lambda2`) to the experimental data, and outputs the predicted strength for given cycles. It also includes enhanced plot visualization and predictions for specific N values (freeze-thaw cycles).

## Requirements

- MATLAB (with Optimization Toolbox)
- Basic knowledge of the Grey Model and its application in material degradation

## Usage

1. **Input Data:** The `x_data` and `N` arrays need to be populated with experimental data corresponding to different freeze-thaw cycles and their corresponding strength values.

2. **Running the Script:**
   - Ensure that the required MATLAB packages (like the Optimization Toolbox) are installed.
   - Run the main script (`LGM_Model_Fitting.m`).
   - The script will output fitted model parameters (`lambda1` and `lambda2`), residuals, and provide predictions for N=15, N=20, and N=30.
   - The plot will display the observed data, fitted curve, and predicted values for N=15, N=20, and N=30.
   - The results will also be saved in a `.mat` file and can be accessed for further analysis.

3. **Plot and Results:**
   - The script will generate a plot showing both the original data points and the fitted curve. The plot will be saved as `LGM_Fitting_Results.png`.
   - The script also saves the fitted results to `mydata.mat`, which contains the fitted parameters and model values.

## Files

- `LGM_Model_Fitting.m`: The main script implementing the LGM model.
- `LGM_Fitting_Results.png`: The plot showing the model fit and experimental data.
- `mydata.mat`: The saved results from the fitting process.

## Example

The example below demonstrates how to run the script:

1. Load your data into `x_data` and `N`.
2. Run the script `LGM_Model_Fitting.m`.
3. View the saved plot and results.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- MATLAB Optimization Toolbox for `lsqcurvefit` function.
- Grey modeling literature for guidance on applying the LGM model to material degradation.
