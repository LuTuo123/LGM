function [R2, RMSE, MAPE] = R2_MAPE(yTrue, yPred)

    yTrue = yTrue(:);
    yPred = yPred(:);

    idxValid = isfinite(yTrue) & isfinite(yPred);
    yTrue = yTrue(idxValid);
    yPred = yPred(idxValid);

    if numel(yTrue) ~= numel(yPred)
        error('yTrue 和 yPred 的长度必须一致。');
    end

    err = yTrue - yPred;

    SSres = sum(err.^2);
    SStot = sum((yTrue - mean(yTrue)).^2);

    if SStot == 0
        R2 = NaN;
    else
        R2 = 1 - SSres / SStot;
    end

    RMSE = rmse(yPred, yTrue);

    idxNonZero = (yTrue ~= 0);
    if any(idxNonZero)
        MAPE = mape(yPred(idxNonZero), yTrue(idxNonZero));
    else
        MAPE = NaN;
    end
end