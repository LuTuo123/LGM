%% LGM Grey Model for Predicting Strength Degradation Under Freeze-Thaw Cycles
fitting_function = @(params, N, H, x0) H + ...
    ((1 - params(2)) * (params(1) * N + (x0 - H)^(1 - params(2)) / (1 - params(2)))) .^ (1 / (1 - params(2)));

%% Input Data
x_data =[259.93 
252.04 
229.98 
217.70 
];  % Ensure x is a set of strength values corresponding to different freeze-thaw cycles N
N = [0; 2; 5; 10];  % The corresponding N values for the data points.
K2=0.35; % Long-term freeze-thaw degradation rate, i.e., the maximum percentage loss in strength x.

K = 1-K2;
H = K * x_data(1);  % Calculate the value of H
x0 = x_data(1);  % The value of x0

%% Start solving the Grey Model
% Initial parameter guesses
lambda1_initial = 1.0; % Initial guess for lambda1
lambda2_initial = 0.5; % Initial guess for lambda2, avoiding 1 to prevent division by zero issues
initial_guess = [lambda1_initial, lambda2_initial];  

% Set constraints on lambda2 to ensure it does not equal 1, avoiding calculation errors
lambda1_lower_bound = -3;  % Lower bound for lambda1
lambda1_upper_bound = 0;   % Upper bound for lambda1, lambda1 < 0

lambda2_lower_bound = 1.01;   % Lower bound for lambda2, lambda2 > 1
lambda2_upper_bound = 3;   % Upper bound for lambda2

% Set bounds for lambda1 and lambda2
lb = [lambda1_lower_bound, lambda2_lower_bound];  % Lower bounds for lambda1 and lambda2
ub = [lambda1_upper_bound, lambda2_upper_bound];  % Upper bounds for lambda1 and lambda2

% Use lsqcurvefit for curve fitting
options = optimset('Display', 'off', 'TolFun', 1e-6, 'TolX', 1e-6);  % Turn off display and set tolerance
[params_fit, resnorm] = lsqcurvefit(@(params, N) fitting_function(params, N, H, x0), initial_guess, N, x_data, lb, ub, options);

% Output the fitted results
lambda1_fit = params_fit(1);
lambda2_fit = params_fit(2);

disp(['Fitted lambda1: ', num2str(lambda1_fit)]);
disp(['Fitted lambda2: ', num2str(lambda2_fit)]);

%% Plot the fitted curve and compare with the actual data
x_fit = fitting_function(params_fit, N, H, x0);

% Plot R^2 and MAPE metrics (you can create a custom function for these)
R2_MAPE(x_data, x_fit)
H

% Enhanced Plot
figure;
hold on;
grid on;

% Plot the original data points
plot(N, x_data, 'bo', 'MarkerFaceColor', 'b', 'MarkerSize', 8);  % Original data points (blue circles)
% Plot the fitted curve
N_smooth = linspace(min(N), max(N), 100);  % Create a smooth range of N for a continuous fit curve
x_smooth = fitting_function(params_fit, N_smooth, H, x0);  % Compute smooth values
plot(N_smooth, x_smooth, 'r-', 'LineWidth', 2);  % Fitted curve (red line)

% Add labels, legend, and title
xlabel('Freeze-Thaw Cycles N', 'FontSize', 14);
ylabel('Strength x', 'FontSize', 14);
legend({'Data Points', 'Fitted Curve'}, 'Location', 'northeast', 'FontSize', 12);
title('LGM Differential Equation Fitting Results', 'FontSize', 16, 'FontWeight', 'bold');

% Make the plot more readable with a grid
grid on;

% Optionally, set axis limits to make the plot clearer
xlim([min(N) - 1, max(N) + 5]);  % Slightly extended X limits
ylim([min(x_data) - 5, max(x_data) + 5]);  % Slightly extended Y limits

% Save the plot as an image
saveas(gcf, 'LGM_Fitting_Results.png');

%% Predict x values for N = 15 and N = 20
N_predict = [15, 20, 30];
x_predict = fitting_function(params_fit, N_predict, H, x0);

% Display prediction results
disp(['Predicted x for N=15: ', num2str(x_predict(1))]);
disp(['Predicted x for N=20: ', num2str(x_predict(2))]);
disp(['Predicted x for N=30: ', num2str(x_predict(3))]);

% Save the fitted results
save mydata.mat x_fit params_fit
clear all
load mydata.mat